package com.dhl.cloudx.cloudxamfmq.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParamDetail {

   private String position;

   public String getPosition() {
      return position;
   }

   public void setPosition(String position) {
      this.position = position;
   }

   public String getHyperLink() {
      return hyperLink;
   }

   public void setHyperLink(String hyperLink) {
      this.hyperLink = hyperLink;
   }

   public String getHyperLinkText() {
      return hyperLinkText;
   }

   public void setHyperLinkText(String hyperLinkText) {
      this.hyperLinkText = hyperLinkText;
   }

   private String hyperLink;
   private String hyperLinkText;


}
