package com.dhl.cloudx.cloudxamfmq.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PathDetails {

   private String path;

   public String getPath() {
      return path;
   }

   public void setPath(String path) {
      this.path = path;
   }


   public List<ParamDetail> getParamDetailList() {
      return ParamDetailList;
   }

   public void setParamDetailList(List<ParamDetail> paramDetailList) {
      ParamDetailList = paramDetailList;
   }

   private List<ParamDetail> ParamDetailList = null;

}
==========


public String GSONSample(){
String rteString="<a href=\"https://www.w3schools.com\"></a> <a href=\"https://stackoverflow.com\">Visit </a>" +
"<A href=\"#section2\">Some background</A><BR>";

PathDetails pathDetails = new PathDetails();
List<ParamDetail> paramDetailList = new ArrayList<ParamDetail>();
Document doc = Jsoup.parseBodyFragment(rteString);
Elements links = doc.select("a");
int poistion =1;
for (Element link : links) {
ParamDetail paramDetail = new ParamDetail();
String linkHref = link.attr("href");
paramDetail.setPosition(poistion+"");
if(!StringUtil.isBlank(linkHref)){
paramDetail.setHyperLink(linkHref);
}
if(!StringUtil.isBlank(link.ownText())){
paramDetail.setHyperLinkText(link.ownText());
}
System.out.println(linkHref);
System.out.println(link.ownText());
poistion = poistion +1;
paramDetailList.add(paramDetail);
}
pathDetails.setParamDetailList(paramDetailList);
String responseJson = "";
responseJson = new Gson().toJson(pathDetails);


return responseJson;

}
